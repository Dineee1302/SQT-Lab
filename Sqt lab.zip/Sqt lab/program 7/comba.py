<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <title>Simple Combo Box</title> 
</head> 
<body> 
    <h2>Simple Combo Box Example</h2> 
 
    <label for="colors">Choose a color:</label> 
    <select id="colors"> 
        <option value="red">Red</option> 
        <option value="green">Green</option> 
        <option value="blue">Blue</option> 
        <option value="yellow">Yellow</option> 
    </select> 
</body> 
</html> 
 
 
package exno7;   
import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.chrome.ChromeDriver; 
import org.openqa.selenium.support.ui.Select; 
import java.time.Duration; 
import java.util.List; 
public class ComboBoxTest {   
    public static void main(String[] args) { 
        System.setProperty("webdriver.chrome.driver", 
                "E:\\Java\\eclipse-workspace\\exno7\\driver\\chromedriver.exe"); 
        WebDriver driver = new ChromeDriver(); 
        driver.manage().window().maximize(); 
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); 
 
 
        try { 
            driver.get("file:///E:/Java/eclipse-workspace/exno7/exno7.html"); 
            WebElement comboBox = driver.findElement(By.id("colors")); 
            Select select = new Select(comboBox); 
            List<WebElement> options = select.getOptions(); 
            System.out.println("Number of items in combo box: " + options.size()); 
            System.out.println("Combo box items:"); 
            for (WebElement option : options) { 
                System.out.println(option.getText()); 
            } 
 
        } catch (Exception e) { 
            e.printStackTrace(); 
        } finally { 
            driver.quit(); 
        } 
    } 
}

<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema
instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven
4.0.0.xsd"> 
  <modelVersion>4.0.0</modelVersion> 
  <groupId>exno7</groupId> 
  <artifactId>exno7</artifactId> 
  <version>0.0.1-SNAPSHOT</version> 
</project>
