Stud.html 
<!DOCTYPE html> 
<html> 
<head> 
    <title>Student Scores</title> 
</head> 
<body> 
    <table id="studentTable" border="1"> 
        <thead> 
            <tr> 
                <th>Name</th> 
                <th>Math</th> 
                <th>English</th> 
                <th>Selenium</th> 
            </tr> 
        </thead> 
        <tbody> 
            <tr> 
                <td>Student 1</td> 
                <td>85</td> 
                <td>72</td> 
                <td>55</td> 

 
            </tr> 
            <tr> 
                <td>Student 2</td> 
                <td>60</td> 
                <td>78</td> 
                <td>68</td> 
            </tr> 
            <tr> 
                <td>Student 3</td> 
                <td>70</td> 
                <td>45</td> 
                <td>75</td> 
            </tr> 
        </tbody> 
    </table> 
</body> 
</html>

StudentScoreCounter 
package StudentScoreCounter; 
import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.chrome.ChromeDriver; 
import java.util.List; 
public class StudentScoreCounter { 
public static void main(String[] args) { 
System.setProperty("webdriver.chrome.driver", "E:\\Java\\eclipse-workspace\\selenium
exno3\\dri\\chromedriver.exe"); 
WebDriver driver = new ChromeDriver(); 
driver.get("file:///E:/Java/stude.html"); 
WebElement table = driver.findElement(By.id("studentTable")); 
List<WebElement> rows = table.findElements(By.xpath(".//tbody/tr")); 
int count = 0; 
for (WebElement row : rows) { 
List<WebElement> cells = row.findElements(By.tagName("td")); 
int math = Integer.parseInt(cells.get(1).getText()); 
int english = Integer.parseInt(cells.get(2).getText()); 
int selenium = Integer.parseInt(cells.get(3).getText()); 
if (math > 60 || english > 60 || selenium > 60) { 
count++; 
} 
} 
System.out.println("Number of students who scored more than 60 in at least one subject: " + count); 
} 
} 
 
Xml 
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema
instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven
4.0.0.xsd"> 
  <modelVersion>4.0.0</modelVersion> 
  <groupId>selenium-exno3</groupId> 
  <artifactId>selenium-exno3</artifactId> 
  <version>0.0.1-SNAPSHOT</version>
  <dependencies> 
    <!-- Selenium Java --> 
    <dependency> 
      <groupId>org.seleniumhq.selenium</groupId> 
      <artifactId>selenium-java</artifactId> 
      <version>4.24.0</version> 
    </dependency> 
  </dependencies> 
</project>
