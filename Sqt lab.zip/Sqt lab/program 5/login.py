<!DOCTYPE html> 
<html> 
<head> 
    <title>Login Page</title> 
</head> 
<body> 
    <h2>Login Form</h2> 
    <form id="loginForm"> 
        <label for="username">Username:</label> 
        <input type="text" id="username" name="username"><br><br> 
        <label for="password">Password:</label> 
        <input type="password" id="password" name="password"><br><br> 
        <button type="submit" id="loginButton">Login</button> 
    </form> 
    <p id="message" style="color:red;"></p> 
    <script> 
        const form = document.getElementById('loginForm'); 
        const message = document.getElementById('message'); 
        form.addEventListener('submit', function(event) { 
            event.preventDefault(); 
            const username = document.getElementById('username').value; 
            const password = document.getElementById('password').value; 
 
            if(username === "Admin" && password === "admin123") { 
                message.style.color = "green"; 
                message.textContent = "Login Successful!"; 
            } else { 
                message.style.color = "red"; 
                message.textContent = "Invalid credentials!"; 
            } 
        }); 
    </script> 
</body> 
</html>

exno5 
package exno5; 
import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 
import static org.junit.Assert.*; 
import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.chrome.ChromeDriver; 
import java.io.File; 
public class exno5 { 
private WebDriver driver; 
@Before 
public void setUp() {        
System.setProperty("webdriver.chrome.driver", "E:\\Java\\eclipse-workspace\\selenium
exno5\\driver\\chromedriver.exe");  
driver = new ChromeDriver(); 
} 
@After 
public void tearDown() { 
} 
@Test 
public void loginTest() { 
File file = new File("src/test/resources/login.html"); 
driver.get(file.getAbsolutePath()); 
String usernameInput = "";      
String passwordInput = "";   
driver.findElement(By.name("username")).sendKeys(usernameInput); 
driver.findElement(By.name("password")).sendKeys(passwordInput); 
driver.findElement(By.id("loginButton")).click(); 
WebElement message = driver.findElement(By.id("message")); 
System.out.println("Login message: " + message.getText()); 
} 
} 

 
xml 
<project xmlns="http://maven.apache.org/POM/4.0.0" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
    xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
    http://maven.apache.org/xsd/maven-4.0.0.xsd"> 
    <modelVersion>4.0.0</modelVersion> 
    <groupId>com.example</groupId> 
    <artifactId>SeleniumLoginTest</artifactId> 
    <version>1.0-SNAPSHOT</version> 
 <dependencies> 
        <!-- Selenium --> 
        <dependency> 
            <groupId>org.seleniumhq.selenium</groupId> 
            <artifactId>selenium-java</artifactId> 
            <version>4.35.0</version> 
        </dependency> 
        <!-- JUnit --> 
        <dependency> 
            <groupId>junit</groupId> 
            <artifactId>junit</artifactId> 
            <version>4.13.2</version> 
        </dependency> 
        <!-- WebDriverManager --> 
        <dependency> 
            <groupId>io.github.bonigarcia</groupId> 
            <artifactId>webdrivermanager</artifactId> 
            <version>5.5.1</version> 
        </dependency> 
    </dependencies>

  <dependencies> 
    <!-- Selenium Java --> 
    <dependency> 
      <groupId>org.seleniumhq.selenium</groupId> 
      <artifactId>selenium-java</artifactId> 
      <version>4.24.0</version> 
    </dependency> 
  </dependencies> 
</project> 
