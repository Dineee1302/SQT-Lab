<!DOCTYPE html> 
<html> 
<head> 
    <title>Test Page</title> 
</head> 
<body> 
    <h1>Welcome</h1> 
    <p>This is a test page.</p> 
    <button>Click Me</button> 
    <a href="#">Link 1</a> 
    <a href="#">Link 2</a>  
</body> 
</html> 
 
 
package exno6; 
import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.chrome.ChromeDriver; 
import java.util.List; 
public class exno6 { 
    public static void main(String[] args) { 
        System.setProperty("webdriver.chrome.driver",  
            "E:\\Java\\eclipse-workspace\\selenium-exno6\\driver\\chromedriver.exe"); 
        WebDriver driver = new ChromeDriver(); 
        try { 
             driver.get("file:///E:/Java/eclipse-workspace/selenium-exno6/src/test/resources/test.html");             

 
            List<WebElement> allElements = driver.findElements(By.xpath("//*")); 
            System.out.println("Total number of objects on the page: " + allElements.size()); 
        } catch (Exception e) { 
            e.printStackTrace(); 
        } finally { 
        } 
    } 
}
xml
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema
instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven
4.0.0.xsd"> 
  <modelVersion>4.0.0</modelVersion> 
  <groupId>selenium-exno6</groupId> 
  <artifactId>selenium-exno6</artifactId> 
  <version>0.0.1-SNAPSHOT</version>
    <dependencies> 
    <!-- Selenium Java --> 
    <dependency> 
      <groupId>org.seleniumhq.selenium</groupId> 
      <artifactId>selenium-java</artifactId> 
      <version>4.24.0</version> 
    </dependency> 
  </dependencies> 
</project>
