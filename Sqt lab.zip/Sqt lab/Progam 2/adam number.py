package eX2; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.chrome.ChromeDriver; 
import java.util.Scanner; 
public class EX2 { 
static boolean isAdam(int n) { 
int r = Integer.parseInt(new StringBuilder(n+"").reverse().toString()); 
return n*n == Integer.parseInt(new StringBuilder(r*r+"").reverse().toString()); 
} 
public static void main(String[] a) { 
System.setProperty("webdriver.chrome.driver","E:\\Java\\eclipse-workspace\\selenium
exno2\\driver\\chromedriver.exe"); 
WebDriver d = new ChromeDriver(); 
Scanner sc = new Scanner(System.in); 
String h = "<html><meta charset='UTF-8'><body style='font-family:Arial;'>"; 
for (int i=1;i<=4;i++) { 
System.out.print("Enter number "+i+": "); 
String in = sc.nextLine(), r; 
try { r = isAdam(Integer.parseInt(in))?"Adam Number":"Not Adam Number"; } 
catch(Exception e){ r="Invalid Input"; } 
h += "<p>Test Case "+i+": "+in+" → "+r+"</p>"; 
 

} 
sc.close(); 
d.get("data:text/html,"+h+"</body></html>"); 
} 
}

main.xml

Apache Maven 
<project xmlns="http://maven.apache.org/POM/4.0.0"  
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"  
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0  
                             https://maven.apache.org/xsd/maven-4.0.0.xsd"> 
  <modelVersion>4.0.0</modelVersion> 
  <groupId>selenium</groupId> 
  <artifactId>selenium-exno2</artifactId> 
  <version>0.0.1-SNAPSHOT</version> 
 
  <dependencies> 
    <!-- Selenium Java --> 
    <dependency> 
      <groupId>org.seleniumhq.selenium</groupId> 
      <artifactId>selenium-java</artifactId> 
      <version>4.24.0</version> 
    </dependency> 
  </dependencies> 
</project> 
